const KEY="portfolio-v4";
const item=(t,o,d,x,img="")=>({title:t,org:o,date:d,desc:x,link:"",image:img});
const lnk=(id,icon,tab,title,sub)=>({id,kind:"link",icon,tab,title,sub,url:"",note:"Add a short line about this profile."});
const lst=(id,icon,tab,title,sub,items)=>({id,kind:"list",icon,tab,title,sub,items});
const DEFAULT={
  profile:{name:"Divya Keerthana S D",tagline:"B.Tech Information Technology · R.M.D. Engineering College",email:"",phone:"",location:"R.M.D. Engineering College",photo:"images/profile.jpg"},
  secs:[
   lnk("linkedin","💼","LinkedIn","LinkedIn Profile","Paste your LinkedIn profile link"),
   {...lnk("github","🐙","GitHub","GitHub Profile","My code and projects on GitHub"),url:"https://github.com/divyakeerthanasarandevi-afk",note:"Browse my repositories and source code."},
   lst("certs","🏅","Certificates","Industry Certificates","Professional certifications from industry bodies and companies",[
    item("Oracle Cloud Infrastructure Certified AI Foundations Associate","Oracle University","August 2026","Oracle Certified Foundations Associate – certificate of recognition.","images/oracle-ai-foundations.png"),
    item("Java Programming Fundamentals","Infosys Springboard","April 2026","Course completion certificate from Infosys Springboard.","images/infosys-java.png"),
    item("Prompt Engineering","Infosys Springboard","June 2026","Course completion certificate from Infosys Springboard.","images/infosys-prompt-engineering.png"),
    item("Data Structures using C++ (24CS201)","CodeTantra","September 2026","Certificate of completion – I Year II Sem, R.M.D. Engineering College.","images/codetantra-ds-cpp.png"),
    item("Software Development Practices","CodeTantra","September 2026","Certificate of completion – I Year I Sem, R.M.D. Engineering College.","images/codetantra-sdp.png")]),
   lst("projects","🚀","Projects","Projects Completed","Academic, personal and team projects",[]),
   lst("intern","🏢","Internship","Internship Attended","Company, role, duration and what you worked on",[item("Web Development – Virtual Internship","CodSoft","25 May 2026 – 25 June 2026","4-week virtual internship in Web Development with wonderful remarks from CodSoft.","images/codsoft-web-development.png")]),
   lst("training","🛠️","Training","Industrial Training","In-plant training, workshops and industrial visits",[]),
   lst("courses","🎓","Online Courses","Online Course Completed","NPTEL and other online courses",[
    item("Soft Skill Development","NPTEL · IIT Kharagpur","Jan – Mar 2026","Elite + Silver · 8-week course · consolidated score 75%.","images/nptel-soft-skill.png"),
    item("Software Testing","NPTEL · IIIT Bangalore","Jul – Oct 2026","Elite · 12-week course · consolidated score 60%.","images/nptel-software-testing.png")]),
   lnk("leetcode","🧩","LeetCode","LeetCode Profile","Paste your LeetCode profile link"),
   lst("ach","🏆","Achievements","Other Achievements","Technical and soft skills: competitions, paper presentations and more",[
    item("Paper Presentation – ICSHAI 2026","Jeppiaar Institute of Technology","19 – 20 Feb 2026","Presented “Whispers of the Mind: AI Speech Analytics for Early Alzheimer’s Risk” at the International Conference on Smart Healthcare Analytics and AI.","images/icshai-2026-paper.png"),
    item("Ramanujan Mathematical Competition – Level 3 (National)","ISTE Tamilnadu Section","21 – 22 Feb 2026","National Level Srinivasa Ramanujan Mathematical Competitions 2025-26 – participation.","images/ramanujan-level-3.jpg"),
    item("Ramanujan Mathematical Competition – Level 2 (State)","ISTE Tamilnadu Section","14 – 15 Feb 2026","State level round of the Srinivasa Ramanujan Mathematical Competitions 2025-26 – participation.","images/ramanujan-level-2.jpg"),
    item("Ramanujan Mathematical Competition – Level 1 (Chapter)","ISTE Tamilnadu Section","24 – 25 Jan 2026","Chapter level round of the Srinivasa Ramanujan Mathematical Competitions 2025-26 – participation.","images/ramanujan-level-1.jpg")]),
  ]};
let S,E=false,tab=0,pendingImg=null;
try{const r=localStorage.getItem(KEY);S=r?JSON.parse(r):null}catch(e){S=null}
if(!S||!S.secs)S=JSON.parse(JSON.stringify(DEFAULT));
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const safe=u=>/^https?:\/\//i.test(u||"")?u:"";
let tm;const toast=m=>{const t=$("toast");t.textContent=m;t.classList.add("show");clearTimeout(tm);tm=setTimeout(()=>t.classList.remove("show"),2200)};
let st;const save=()=>{clearTimeout(st);st=setTimeout(()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){toast("Storage full: remove some images")}},300)};
const get=p=>p.split(".").reduce((o,k)=>o[k],S);
const setP=(p,v)=>{const k=p.split(".");const l=k.pop();k.reduce((o,x)=>o[x],S)[l]=v};
const ed=(p,ph,tag="span",cls="")=>`<${tag} class="${cls}" data-p="${p}" data-ph="${esc(ph)}"${E?' contenteditable="true"':""}>${esc(get(p))}</${tag}>`;

function hero(){
  const P=S.profile,ph=P.photo?`<img src="${esc(P.photo)}" alt="">`:"Your photo";
  const chip=(ic,key,ph,href)=>E?`<span class="chip">${ic} ${ed("profile."+key,ph)}</span>`:(P[key]?`<a class="chip" href="${href}">${ic} ${esc(P[key])}</a>`:"");
  return `<div class="hero"><div class="photo">${ph}</div>
   <div class="mini" style="justify-content:center;margin-bottom:10px"><button data-act="photo">Upload photo</button></div>
   ${ed("profile.name","Your name","h1")}<p class="tg">${ed("profile.tagline","Tagline")}</p>
   <div class="contact">${chip("✉","email","you@example.com","mailto:"+esc(P.email))}${chip("📞","phone","Phone number","tel:"+esc(P.phone.replace(/[^\d+]/g,"")))}${chip("📍","location","City, State","#")}</div></div>`;
}
function linkSec(i){
  const s=S.secs[i],u=safe(s.url),b=`secs.${i}`;
  return `<h2 class="t">${esc(s.title)}</h2><p class="sub">${ed(b+".sub","Description")}</p>
  <div class="card big"><span class="ico">${esc(s.icon)}</span>${ed(b+".note","Short note","p")}
  ${E?`<span class="lk">URL: ${ed(b+".url","https://...")}</span>`:(u?`<a class="go" href="${esc(u)}" target="_blank" rel="noopener">Open ${esc(s.tab)} →</a><span class="lk" style="color:var(--muted)">${esc(u)}</span>`:`<p>Link not added yet. Press Edit to add it.</p>`)}</div>`;
}
function listSec(i){
  const s=S.secs[i];
  return `<h2 class="t">${esc(s.title)}</h2><p class="sub">${ed(`secs.${i}.sub`,"Description")}</p><div class="grid">`+
  s.items.map((it,j)=>{const b=`secs.${i}.items.${j}`,u=safe(it.link);
   return `<article class="card"><button class="del" data-act="del" data-i="${i}" data-j="${j}">×</button>
    ${it.image?`<div class="slot has" role="button" tabindex="0" title="View full certificate" data-act="zoom" data-i="${i}" data-j="${j}"><img src="${esc(it.image)}" alt="${esc(it.title)}"></div>`:`<div class="slot">Space for certificate / proof image</div>`}
    <div class="mini"><button data-act="img" data-i="${i}" data-j="${j}">Upload image</button>${it.image?`<button data-act="rmimg" data-i="${i}" data-j="${j}">Remove image</button>`:""}</div>
    <span class="badge">${ed(b+".date","Date")}</span>${ed(b+".title","Title","h3")}<div class="org">${ed(b+".org","Organisation")}</div>${ed(b+".desc","Description","p")}
    ${E?`<span class="lk">Link: ${ed(b+".link","https://...")}</span>`:(u?`<a class="lk" href="${esc(u)}" target="_blank" rel="noopener">View certificate / link →</a>`:"")}</article>`}).join("")+
  `${!s.items.length&&!E?'<p class="sub" style="margin-left:0">Coming soon…</p>':""}<button class="card add" data-act="add" data-i="${i}">+ Add entry</button></div>`;
}
function render(){
  document.body.classList.toggle("editing",E);$("editBtn").classList.toggle("on",E);$("editBtn").textContent=E?"✔ Done":"✎ Edit";
  $("tabs").innerHTML=S.secs.map((s,i)=>`<button class="tab${i===tab?" act":""}" data-act="tab" data-id="${i}">${esc(s.icon+" "+s.tab)}</button>`).join("");
  $("hero").innerHTML=hero();
  $("panel").innerHTML=S.secs[tab].kind==="link"?linkSec(tab):listSec(tab);
  $("brand").textContent=S.profile.name;document.title=S.profile.name+" | Portfolio";
  $("foot").textContent="© "+new Date().getFullYear()+" "+S.profile.name;
}
function pick(path){pendingImg=path;$("file").value="";$("file").click()}
$("file").onchange=e=>{const f=e.target.files[0];if(!f||!pendingImg)return;const r=new FileReader();
  r.onload=()=>{const im=new Image();im.onload=()=>{const m=pendingImg.endsWith("photo")?400:900,k=Math.min(1,m/im.width),c=document.createElement("canvas");
    c.width=im.width*k;c.height=im.height*k;c.getContext("2d").drawImage(im,0,0,c.width,c.height);setP(pendingImg,c.toDataURL("image/jpeg",.8));save();render();toast("Image added")};im.src=r.result};r.readAsDataURL(f)};
let rs=false;
function closeLb(){$("lb").classList.remove("show","full");document.body.style.overflow="";$("lbimg").removeAttribute("src")}
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeLb();if((e.key==="Enter"||e.key===" ")&&e.target.classList&&e.target.classList.contains("has")){e.preventDefault();e.target.click()}});
document.addEventListener("click",e=>{
  const t=e.target.closest("[data-act]");if(!t)return;const a=t.dataset.act,i=+t.dataset.i,j=+t.dataset.j;
  if(a==="zoom"){const it=S.secs[i].items[j];$("lbimg").src=it.image;$("lbcap").textContent=[it.title,it.org].filter(Boolean).join(" · ");$("lb").classList.remove("full");$("lbfit").textContent="Actual size";$("lb").classList.add("show");document.body.style.overflow="hidden"}
  else if(a==="lbclose"||a==="lbbg"&&e.target===t){closeLb()}
  else if(a==="lbfit"){const f=$("lb").classList.toggle("full");$("lbfit").textContent=f?"Fit to screen":"Actual size"}
  else if(a==="tab"){tab=+t.dataset.id;render();$("panel").scrollIntoView({behavior:"smooth"})}
  else if(a==="edit"){E=!E;render();if(!E)toast("Saved")}
  else if(a==="add"){S.secs[i].items.push(item("Title","Organisation","Month YYYY","Short description."));save();render()}
  else if(a==="del"){S.secs[i].items.splice(j,1);save();render()}
  else if(a==="img")pick(`secs.${i}.items.${j}.image`);
  else if(a==="rmimg"){S.secs[i].items[j].image="";save();render()}
  else if(a==="photo")pick("profile.photo");
  else if(a==="backup"){$("bk").value=JSON.stringify(S);$("modal").classList.add("show")}
  else if(a==="close")$("modal").classList.remove("show");
  else if(a==="copy"){$("bk").select();try{document.execCommand("copy");toast("Copied")}catch(x){toast("Press Ctrl+C to copy")}}
  else if(a==="load"){try{const d=JSON.parse($("bk").value);if(!d.secs||!d.profile)throw 0;S=d;tab=0;save();$("modal").classList.remove("show");render();toast("Restored")}catch(x){toast("That text is not valid backup data")}}
  else if(a==="reset"){if(!rs){rs=true;t.textContent="Tap again to confirm";setTimeout(()=>{rs=false;t.textContent="Reset"},3000)}else{rs=false;S=JSON.parse(JSON.stringify(DEFAULT));tab=0;save();render();toast("Reset to template")}}
});
document.addEventListener("input",e=>{const p=e.target.dataset&&e.target.dataset.p;if(p&&E){setP(p,e.target.innerText.replace(/\n+/g," ").trim());save()}});
document.addEventListener("paste",e=>{if(e.target.isContentEditable){e.preventDefault();document.execCommand("insertText",false,(e.clipboardData||window.clipboardData).getData("text/plain"))}});
document.addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.isContentEditable)e.preventDefault()});
render();
